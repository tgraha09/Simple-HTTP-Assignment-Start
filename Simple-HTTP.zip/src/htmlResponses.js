module.exports = {
  other: '',
  meme: '<img src="https://preview.redd.it/1s8mx9v07r331.png?auto=webp&s=e1decdfa675734cc1c2c3bf4a1fbb957aeb49122"></img>',
};
