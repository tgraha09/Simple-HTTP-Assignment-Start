module.exports = {
  hello: 'Hello',
  time: new Date().toTimeString().split(' ')[0],
};
